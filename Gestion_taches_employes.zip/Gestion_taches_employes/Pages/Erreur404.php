<div class="container-fluid px-4">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <div class="text-center mt-4">
                <img class="mb-4 img-error" src="Public/assets/img/error-404-monochrome.svg" alt="Erreur 404" 
                     style="width: 100%; max-width: 500px;" />
                <p class="lead">Cette page n'existe pas.</p>
                <a href="Index.php">
                    <i class="fas fa-arrow-left me-1"></i>
                    Retour à l'accueil
                </a>
            </div>
        </div>
    </div>
</div>
