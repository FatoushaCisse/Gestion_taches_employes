<?php
// Récupération de l'ID de la tâche à modifier
$idTache = isset($_GET['id']) ? intval($_GET['id']) : 0;
$tache = obtenirTache($idTache);

// Redirection si la tâche n'existe pas
if (!$tache) {
    header('Location: Index.php?page=indexTache');
    exit;
}

// Vérifier si la tâche est modifiable (pas terminée)
$estTerminee = $tache['statut'] == 'terminée';
?>

<h1 class="mt-4">Modifier une Tâche</h1>
<ol class="breadcrumb mb-4">
    <li class="breadcrumb-item"><a href="Index.php">Accueil</a></li>
    <li class="breadcrumb-item"><a href="Index.php?page=indexTache">Gestion des Tâches</a></li>
    <li class="breadcrumb-item active">Modifier</li>
</ol>

<?php if ($estTerminee): ?>
    <div class="alert alert-warning">
        <i class="fas fa-exclamation-triangle"></i>
        <strong>Attention :</strong> Cette tâche est terminée. Selon les règles métier, 
        seules les tâches "à faire" et "en cours" peuvent être modifiées.
    </div>
<?php endif; ?>

<?php
// Affichage des messages d'erreur
if (isset($_GET['error'])) {
    echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-circle"></i> Erreur : Tous les champs obligatoires doivent être remplis.
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
          </div>';
}
?>

<div class="row">
    <div class="col-xl-8 col-md-10 mx-auto">
        <div class="card mb-4">
            <div class="card-header bg-warning text-dark">
                <i class="fas fa-edit me-1"></i>
                Modification de la Tâche #<?= $tache['id'] ?>
            </div>
            <div class="card-body">
                <form method="POST" action="Traitements/action.php">
                    <input type="hidden" name="action" value="modifier">
                    <input type="hidden" name="id" value="<?= $tache['id'] ?>">
                    
                    <div class="mb-3">
                        <label for="titre" class="form-label">
                            Titre <span class="text-danger">*</span>
                        </label>
                        <input type="text" class="form-control" id="titre" name="titre" 
                               value="<?= htmlspecialchars($tache['titre']) ?>" 
                               <?= $estTerminee ? 'readonly' : 'required' ?>>
                    </div>
                    
                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea class="form-control" id="description" name="description" 
                                  rows="4" <?= $estTerminee ? 'readonly' : '' ?>><?= htmlspecialchars($tache['description']) ?></textarea>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label for="priorite" class="form-label">
                                Priorité <span class="text-danger">*</span>
                            </label>
                            <select class="form-select" id="priorite" name="priorite" 
                                    <?= $estTerminee ? 'disabled' : 'required' ?>>
                                <option value="basse" <?= $tache['priorite'] == 'basse' ? 'selected' : '' ?>>Basse</option>
                                <option value="moyenne" <?= $tache['priorite'] == 'moyenne' ? 'selected' : '' ?>>Moyenne</option>
                                <option value="haute" <?= $tache['priorite'] == 'haute' ? 'selected' : '' ?>>Haute</option>
                            </select>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label for="statut" class="form-label">
                                Statut <span class="text-danger">*</span>
                            </label>
                            <select class="form-select" id="statut" name="statut" 
                                    <?= $estTerminee ? 'disabled' : 'required' ?>>
                                <option value="à faire" <?= $tache['statut'] == 'à faire' ? 'selected' : '' ?>>À faire</option>
                                <option value="en cours" <?= $tache['statut'] == 'en cours' ? 'selected' : '' ?>>En cours</option>
                                <option value="terminée" <?= $tache['statut'] == 'terminée' ? 'selected' : '' ?>>Terminée</option>
                            </select>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label for="dateLimite" class="form-label">
                                Date Limite <span class="text-danger">*</span>
                            </label>
                            <input type="date" class="form-control" id="dateLimite" name="dateLimite" 
                                   value="<?= date('Y-m-d', strtotime($tache['dateLimite'])) ?>"
                                   <?= $estTerminee ? 'readonly' : 'required' ?>>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="responsable" class="form-label">
                            Responsable (Nom et Prénom) <span class="text-danger">*</span>
                        </label>
                        <input type="text" class="form-control" id="responsable" name="responsable" 
                               value="<?= htmlspecialchars($tache['responsable']) ?>"
                               <?= $estTerminee ? 'readonly' : 'required' ?>>
                    </div>
                    
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle"></i>
                        <strong>Informations :</strong>
                        <ul class="mb-0">
                            <li>Date de création : <?= date('d/m/Y à H:i', strtotime($tache['dateCreation'])) ?></li>
                            <?php if (estEnRetard($tache)): ?>
                                <li class="text-danger">
                                    <i class="fas fa-exclamation-triangle"></i>
                                    <strong>Cette tâche est en retard !</strong>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                    
                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                        <a href="Index.php?page=indexTache" class="btn btn-secondary me-md-2">
                            <i class="fas fa-times"></i> Annuler
                        </a>
                        <?php if (!$estTerminee): ?>
                            <button type="submit" class="btn btn-success">
                                <i class="fas fa-save"></i> Enregistrer les Modifications
                            </button>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<style>
.form-label {
    font-weight: 600;
}
</style>
