<?php
// Récupération des tâches
$taches = chargerTaches();

// Gestion de la recherche
$recherche = isset($_GET['search']) ? trim($_GET['search']) : '';
if (!empty($recherche)) {
    $taches = rechercherTaches($recherche);
}

// Gestion des filtres
$filtreStatut = isset($_GET['filtre_statut']) ? $_GET['filtre_statut'] : '';
$filtrePriorite = isset($_GET['filtre_priorite']) ? $_GET['filtre_priorite'] : '';

if (!empty($filtreStatut)) {
    $taches = filtrerParStatut($filtreStatut);
}

if (!empty($filtrePriorite)) {
    $taches = filtrerParPriorite($filtrePriorite);
}

// Messages de succès
$message = '';
if (isset($_GET['message'])) {
    switch($_GET['message']) {
        case 'ajout_success':
            $message = '<div class="alert alert-success alert-dismissible fade show">
                          <i class="fas fa-check-circle"></i> Tâche ajoutée avec succès !
                          <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>';
            break;
        case 'modif_success':
            $message = '<div class="alert alert-success alert-dismissible fade show">
                          <i class="fas fa-check-circle"></i> Tâche modifiée avec succès !
                          <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>';
            break;
        case 'suppression_success':
            $message = '<div class="alert alert-success alert-dismissible fade show">
                          <i class="fas fa-check-circle"></i> Tâche supprimée avec succès !
                          <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>';
            break;
        case 'statut_change':
            $message = '<div class="alert alert-info alert-dismissible fade show">
                          <i class="fas fa-info-circle"></i> Statut de la tâche modifié !
                          <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>';
            break;
    }
}
?>

<h1 class="mt-4">Gestion des Tâches</h1>
<ol class="breadcrumb mb-4">
    <li class="breadcrumb-item"><a href="Index.php">Accueil</a></li>
    <li class="breadcrumb-item active">Gestion des Tâches</li>
</ol>

<?= $message ?>

<!-- Barre d'actions et filtres -->
<div class="card mb-4">
    <div class="card-body">
        <div class="row align-items-center">
            <div class="col-md-3 mb-2">
                <a href="Index.php?page=ajouterTache" class="btn btn-primary w-100">
                    <i class="fas fa-plus"></i> Nouvelle Tâche
                </a>
            </div>
            
            <div class="col-md-3 mb-2">
                <select class="form-select" id="filtreStatut" onchange="filtrerTaches()">
                    <option value="">Tous les statuts</option>
                    <option value="à faire" <?= $filtreStatut == 'à faire' ? 'selected' : '' ?>>À faire</option>
                    <option value="en cours" <?= $filtreStatut == 'en cours' ? 'selected' : '' ?>>En cours</option>
                    <option value="terminée" <?= $filtreStatut == 'terminée' ? 'selected' : '' ?>>Terminée</option>
                </select>
            </div>
            
            <div class="col-md-3 mb-2">
                <select class="form-select" id="filtrePriorite" onchange="filtrerTaches()">
                    <option value="">Toutes les priorités</option>
                    <option value="haute" <?= $filtrePriorite == 'haute' ? 'selected' : '' ?>>Haute</option>
                    <option value="moyenne" <?= $filtrePriorite == 'moyenne' ? 'selected' : '' ?>>Moyenne</option>
                    <option value="basse" <?= $filtrePriorite == 'basse' ? 'selected' : '' ?>>Basse</option>
                </select>
            </div>
            
            <div class="col-md-3 mb-2">
                <span class="badge bg-secondary">Total: <?= count($taches) ?> tâche(s)</span>
            </div>
        </div>
    </div>
</div>

<!-- Liste des tâches -->
<?php if (empty($taches)): ?>
    <div class="alert alert-info text-center">
        <i class="fas fa-info-circle fa-3x mb-3"></i>
        <h4>Aucune tâche trouvée</h4>
        <p>Commencez par créer votre première tâche.</p>
        <a href="Index.php?page=ajouterTache" class="btn btn-primary">
            <i class="fas fa-plus"></i> Créer une tâche
        </a>
    </div>
<?php else: ?>
    <div class="row">
        <?php foreach ($taches as $tache): ?>
            <?php $enRetard = estEnRetard($tache); ?>
            <div class="col-xl-4 col-md-6 mb-4">
                <div class="card h-100 shadow-sm <?= $enRetard ? 'border-danger' : '' ?>">
                    <?php if ($enRetard): ?>
                        <div class="card-header bg-danger text-white">
                            <i class="fas fa-exclamation-triangle"></i> EN RETARD
                        </div>
                    <?php endif; ?>
                    
                    <div class="card-body">
                        <h5 class="card-title">
                            <?= htmlspecialchars($tache['titre']) ?>
                        </h5>
                        
                        <p class="card-text text-muted">
                            <?= htmlspecialchars(substr($tache['description'], 0, 100)) ?>
                            <?= strlen($tache['description']) > 100 ? '...' : '' ?>
                        </p>
                        
                        <div class="mb-2">
                            <span class="badge bg-<?= getClassePriorite($tache['priorite']) ?>">
                                <i class="fas fa-flag"></i> <?= ucfirst($tache['priorite']) ?>
                            </span>
                            <span class="badge bg-<?= getClasseStatut($tache['statut']) ?>">
                                <?= ucfirst($tache['statut']) ?>
                            </span>
                        </div>
                        
                        <div class="small text-muted mb-3">
                            <div><i class="fas fa-user"></i> <?= htmlspecialchars($tache['responsable']) ?></div>
                            <div><i class="fas fa-calendar"></i> Date limite: 
                                <strong class="<?= $enRetard ? 'text-danger' : '' ?>">
                                    <?= date('d/m/Y', strtotime($tache['dateLimite'])) ?>
                                </strong>
                            </div>
                            <div><i class="fas fa-clock"></i> Créée le: 
                                <?= date('d/m/Y à H:i', strtotime($tache['dateCreation'])) ?>
                            </div>
                        </div>
                        
                        <!-- Changement de statut -->
                        <div class="mb-3">
                            <strong class="d-block mb-1 small">Changer le statut :</strong>
                            <div class="btn-group btn-group-sm w-100" role="group">
                                <?php if ($tache['statut'] != 'à faire'): ?>
                                    <a href="Traitements/action.php?action=changerStatut&id=<?= $tache['id'] ?>&statut=à faire" 
                                       class="btn btn-outline-secondary">
                                        À faire
                                    </a>
                                <?php endif; ?>
                                
                                <?php if ($tache['statut'] != 'en cours'): ?>
                                    <a href="Traitements/action.php?action=changerStatut&id=<?= $tache['id'] ?>&statut=en cours" 
                                       class="btn btn-outline-primary">
                                        En cours
                                    </a>
                                <?php endif; ?>
                                
                                <?php if ($tache['statut'] != 'terminée'): ?>
                                    <a href="Traitements/action.php?action=changerStatut&id=<?= $tache['id'] ?>&statut=terminée" 
                                       class="btn btn-outline-success">
                                        Terminée
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card-footer bg-transparent">
                        <div class="d-flex justify-content-between">
                            <?php if ($tache['statut'] != 'terminée'): ?>
                                <a href="Index.php?page=modifierTache&id=<?= $tache['id'] ?>" 
                                   class="btn btn-sm btn-warning">
                                    <i class="fas fa-edit"></i> Modifier
                                </a>
                            <?php else: ?>
                                <span class="text-muted small">
                                    <i class="fas fa-check-circle"></i> Terminée
                                </span>
                            <?php endif; ?>
                            
                            <a href="Traitements/action.php?action=supprimer&id=<?= $tache['id'] ?>" 
                               class="btn btn-sm btn-danger"
                               onclick="return confirm('Êtes-vous sûr de vouloir supprimer cette tâche ?');">
                                <i class="fas fa-trash"></i> Supprimer
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<script>
function filtrerTaches() {
    const statut = document.getElementById('filtreStatut').value;
    const priorite = document.getElementById('filtrePriorite').value;
    const search = new URLSearchParams(window.location.search).get('search') || '';
    
    let url = 'Index.php?page=indexTache';
    if (statut) url += '&filtre_statut=' + statut;
    if (priorite) url += '&filtre_priorite=' + priorite;
    if (search) url += '&search=' + search;
    
    window.location.href = url;
}
</script>

<style>
.card {
    transition: transform 0.2s;
}
.card:hover {
    transform: translateY(-5px);
}
</style>
