<?php
$stats = calculerStatistiques();
$tachesEnRetard = obtenirTachesEnRetard();
$taches = chargerTaches();

// Compter par statut
$aFaire = count(filtrerParStatut('à faire'));
$enCours = count(filtrerParStatut('en cours'));
$terminees = count(filtrerParStatut('terminée'));
?>

<h1 class="mt-4">Tableau de Bord</h1>
<ol class="breadcrumb mb-4">
    <li class="breadcrumb-item"><a href="Index.php">Accueil</a></li>
    <li class="breadcrumb-item active">Tableau de Bord</li>
</ol>

<!-- Cartes de statistiques -->
<div class="row">
    <div class="col-xl-3 col-md-6">
        <div class="card bg-primary text-white mb-4">
            <div class="card-body">
                <h3><?= $stats['total'] ?></h3>
                <p class="mb-0">Total des Tâches</p>
            </div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                <a class="small text-white stretched-link" href="Index.php?page=indexTache">Voir les détails</a>
                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6">
        <div class="card bg-success text-white mb-4">
            <div class="card-body">
                <h3><?= $stats['terminees'] ?></h3>
                <p class="mb-0">Tâches Terminées</p>
            </div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                <a class="small text-white stretched-link" href="Index.php?page=indexTache&filtre_statut=terminée">Voir les tâches</a>
                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6">
        <div class="card bg-info text-white mb-4">
            <div class="card-body">
                <h3><?= $stats['pourcentage'] ?>%</h3>
                <p class="mb-0">Taux de Complétion</p>
            </div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                <span class="small text-white">Pourcentage terminées</span>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6">
        <div class="card bg-danger text-white mb-4">
            <div class="card-body">
                <h3><?= $stats['enRetard'] ?></h3>
                <p class="mb-0">Tâches en Retard</p>
            </div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                <span class="small text-white">Nécessitent attention</span>
                <div class="small text-white"><i class="fas fa-exclamation-triangle"></i></div>
            </div>
        </div>
    </div>
</div>


<!-- Liste des tâches en retard -->
<?php if (!empty($tachesEnRetard)): ?>
<div class="row">
    <div class="col-xl-12">
        <div class="card mb-4">
            <div class="card-header bg-danger text-white">
                <i class="fas fa-exclamation-triangle me-1"></i>
                Tâches en Retard - Attention Requise !
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Titre</th>
                                <th>Responsable</th>
                                <th>Date Limite</th>
                                <th>Statut</th>
                                <th>Priorité</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($tachesEnRetard as $tache): ?>
                                <tr>
                                    <td><?= htmlspecialchars($tache['titre']) ?></td>
                                    <td><?= htmlspecialchars($tache['responsable']) ?></td>
                                    <td class="text-danger">
                                        <i class="fas fa-clock"></i>
                                        <?= date('d/m/Y', strtotime($tache['dateLimite'])) ?>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?= getClasseStatut($tache['statut']) ?>">
                                            <?= ucfirst($tache['statut']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?= getClassePriorite($tache['priorite']) ?>">
                                            <?= ucfirst($tache['priorite']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="Index.php?page=modifierTache&id=<?= $tache['id'] ?>" 
                                           class="btn btn-sm btn-warning">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

