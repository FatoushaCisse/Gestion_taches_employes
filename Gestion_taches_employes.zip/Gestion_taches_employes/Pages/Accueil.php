<h1 class="mt-4">Bienvenue dans le Système de Gestion des Tâches</h1>
<ol class="breadcrumb mb-4">
    <li class="breadcrumb-item active">Accueil</li>
</ol>

<div class="row">
    <div class="col-md-12">
        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-info-circle me-1"></i>
                À propos du système
            </div>
            <div class="card-body">
                <p>Ce système vous permet de gérer efficacement les tâches de votre entreprise. Vous pouvez :</p>
                <ul>
                    <li>Créer et organiser des tâches avec différents niveaux de priorité</li>
                    <li>Suivre l'état d'avancement de chaque tâche</li>
                    <li>Définir des dates limites et recevoir des alertes pour les tâches en retard</li>
                    <li>Rechercher et filtrer les tâches selon vos besoins</li>
                </ul>
                
                <div class="mt-4">
                    <a href="Index.php?page=ajouterTache" class="btn btn-primary">
                        <i class="fas fa-plus"></i> Créer une nouvelle tâche
                    </a>
                    <a href="Index.php?page=indexTache" class="btn btn-success">
                        <i class="fas fa-list"></i> Voir toutes les tâches
                    </a>
                    <a href="Index.php?page=dashboard" class="btn btn-info">
                        <i class="fas fa-chart-bar"></i> Tableau de bord
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Affichage des tâches récentes
$taches = chargerTaches();
$tachesRecentes = array_slice(array_reverse($taches), 0, 5);
?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <i class="fas fa-clock me-1"></i>
                Tâches récentes
            </div>
            <div class="card-body">
                <?php if (empty($tachesRecentes)): ?>
                    <p class="text-muted">Aucune tâche créée pour le moment.</p>
                <?php else: ?>
                    <div class="list-group">
                        <?php foreach ($tachesRecentes as $tache): ?>
                            <a href="Index.php?page=indexTache" class="list-group-item list-group-item-action">
                                <div class="d-flex w-100 justify-content-between">
                                    <h6 class="mb-1"><?= htmlspecialchars($tache['titre']) ?></h6>
                                    <small>
                                        <span class="badge bg-<?= getClassePriorite($tache['priorite']) ?>">
                                            <?= ucfirst($tache['priorite']) ?>
                                        </span>
                                    </small>
                                </div>
                                <p class="mb-1 text-truncate"><?= htmlspecialchars($tache['description']) ?></p>
                                <small class="text-muted">
                                    Responsable: <?= htmlspecialchars($tache['responsable']) ?> | 
                                    Date limite: <?= date('d/m/Y', strtotime($tache['dateLimite'])) ?>
                                </small>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
