<?php  
$dossierPublic = "Public/";
include_once("Includes/header.php");
include_once("Includes/navbar.php");
include_once("Includes/sidebar.php");
require_once("Traitements/functions.php");

// Récupération de la page demandée
$page = isset($_GET['page']) ? $_GET['page'] : 'Accueil';

// Vérification de l'existence de la page
if(file_exists("Pages/$page.php")){
    include("Pages/$page.php");
} else {
    include_once("Pages/Erreur404.php");
}

include_once("Includes/footer.php");
?>