<div>
        </main>
        <footer class="py-4 bg-light mt-auto">
            <div class="container-fluid px-4">
                <div class="d-flex align-items-center justify-content-between small">
                    <div class="text-muted">Copyright &copy; Gestion Tâches 2026</div>
                    <div>
                        <a href="#">Politique de confidentialité</a>
                        &middot;
                        <a href="#">Conditions d'utilisation</a>
                    </div>
                </div>
            </div>
        </footer>
    </div>
</div>
<script src="<?= $dossierPublic ?>js/bootstrap/bootstrap5/js/bootstrap.bundle.js" crossorigin="anonymous"></script>
<script src="<?= $dossierPublic ?>js/scripts.js"></script>
<script src="<?= $dossierPublic ?>assets/demo/chart-area-demo.js"></script>
<script src="<?= $dossierPublic ?>assets/demo/chart-bar-demo.js"></script>
<script src="<?= $dossierPublic ?>js/datatables-simple-demo.js"></script>
</body>
</html>
