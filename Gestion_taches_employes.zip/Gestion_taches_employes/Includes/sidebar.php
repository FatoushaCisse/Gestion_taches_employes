<div id="layoutSidenav">
    <div id="layoutSidenav_nav">
        <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
            <div class="sb-sidenav-menu">
                <div class="nav">
                    <div class="sb-sidenav-menu-heading">MENU</div>
                    
                    <a class="nav-link" href="Index.php?page=dashboard">
                        <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                        Tableau de Bord
                    </a>
                    
                    <a class="nav-link" href="Index.php?page=indexTache">
                        <div class="sb-nav-link-icon"><i class="fas fa-tasks"></i></div>
                        Gestion des Tâches
                    </a>
                    
                    <a class="nav-link" href="Index.php?page=ajouterTache">
                        <div class="sb-nav-link-icon"><i class="fas fa-plus-circle"></i></div>
                        Ajouter une Tâche
                    </a>
                </div>
            </div>
        </nav>
    </div>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4">
