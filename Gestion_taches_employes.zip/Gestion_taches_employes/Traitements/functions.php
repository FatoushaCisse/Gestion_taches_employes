<?php
// Chemin vers le fichier JSON
define('FICHIER_TACHES', __DIR__ . '/../connexion/taches.json');

/**
 * Charger toutes les tâches depuis le fichier JSON
 */
function chargerTaches() {
    if (!file_exists(FICHIER_TACHES)) {
        return [];
    }
    
    $json = file_get_contents(FICHIER_TACHES);
    $taches = json_decode($json, true);
    
    return $taches ? $taches : [];
}


//  Sauvegarder les tâches dans le fichier JSON
function sauvegarderTaches($taches) {
    $json = json_encode($taches, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    return file_put_contents(FICHIER_TACHES, $json);
}

//  Générer un ID unique pour une nouvelle tâche
function genererIdTache() {
    $taches = chargerTaches();
    if (empty($taches)) {
        return 1;
    }
    
    $ids = array_column($taches, 'id');
    return max($ids) + 1;
}


//  Ajouter une nouvelle tâche

function ajouterTache($titre, $description, $priorite, $datecreation,$datelimite, $responsable) {
    $taches = chargerTaches();
    
    $nouvelleTache = [
        'id' => genererIdTache(),
        'titre' => $titre,
        'description' => $description,
        'priorite' => $priorite,
        'statut' => 'à faire',
        'dateCreation' => date('Y-m-d H:i:s'),
        'dateLimite' => $datelimite,
        'responsable' => $responsable
    ];
    
    $taches[] = $nouvelleTache;
    sauvegarderTaches($taches);
    
    return $nouvelleTache;
}

//  Obtenir une tâche par son ID

function obtenirTache($id) {
    $taches = chargerTaches();
    
    foreach ($taches as $tache) {
        if ($tache['id'] == $id) {
            return $tache;
        }
    }
    
    return null;
}


// Modifier une tâche existante

function modifierTache($titre, $description, $priorite, $statut, $dateLimite, $responsable) {
    $taches = chargerTaches();
    
    foreach ($taches as $index => $tache) {
        if ($tache['id'] == $id) {
            $taches[$index]['titre'] = $titre;
            $taches[$index]['description'] = $description;
            $taches[$index]['priorite'] = $priorite;
            $taches[$index]['statut'] = $statut;
            $taches[$index]['dateLimite'] = $dateLimite;
            $taches[$index]['responsable'] = $responsable;
            
            sauvegarderTaches($taches);
            return true;
        }
    }
    
    return false;
}

//  Changer le statut d'une tâche
function changerStatut($id, $nouveauStatut) {
    $taches = chargerTaches();
    
    foreach ($taches as $index => $tache) {
        if ($tache['id'] == $id) {
            $taches[$index]['statut'] = $nouveauStatut;
            sauvegarderTaches($taches);
            return true;
        }
    }
    
    return false;
}

// Supprimer une tâche
function supprimerTache($id) {
    $taches = chargerTaches();
    
    foreach ($taches as $index => $tache) {
        if ($tache['id'] == $id) {
            unset($taches[$index]);
            $taches = array_values($taches); // Réindexer le tableau
            sauvegarderTaches($taches);
            return true;
        }
    }
    
    return false;
}

// Rechercher des tâches par mot-clé
function rechercherTaches($motCle) {
    $taches = chargerTaches();
    $resultats = [];
    
    foreach ($taches as $tache) {
        if (stripos($tache['titre'], $motCle) !== false || 
            stripos($tache['description'], $motCle) !== false) {
            $resultats[] = $tache;
        }
    }
    
    return $resultats;
}

// Filtrer les tâches par statut
function filtrerParStatut($statut) {
    $taches = chargerTaches();
    
    if (empty($statut)) {
        return $taches;
    }
    
    return array_filter($taches, function($tache) use ($statut) {
        return $tache['statut'] == $statut;
    });
}

// Filtrer les tâches par priorité
function filtrerParPriorite($priorite) {
    $taches = chargerTaches();
    
    if (empty($priorite)) {
        return $taches;
    }
    
    return array_filter($taches, function($tache) use ($priorite) {
        return $tache['priorite'] == $priorite;
    });
}

// Vérifier si une tâche est en retard
function estEnRetard($tache) {
    if ($tache['statut'] == 'terminée') {
        return false;
    }
    
    $dateActuelle = new DateTime();
    $dateLimite = new DateTime($tache['dateLimite']);
    
    return $dateActuelle > $dateLimite;
}

// Obtenir les tâches en retard
function obtenirTachesEnRetard() {
    $taches = chargerTaches();
    $tachesEnRetard = [];
    
    foreach ($taches as $tache) {
        if (estEnRetard($tache)) {
            $tachesEnRetard[] = $tache;
        }
    }
    
    return $tachesEnRetard;
}

// Calculer les statistiques
function calculerStatistiques() {
    $taches = chargerTaches();
    $totalTaches = count($taches);
    
    $tachesTerminees = array_filter($taches, function($tache) {
        return $tache['statut'] == 'terminée';
    });
    
    $nombreTerminees = count($tachesTerminees);
    $pourcentageTerminees = $totalTaches > 0 ? round(($nombreTerminees / $totalTaches) * 100, 2) : 0;
    $nombreEnRetard = count(obtenirTachesEnRetard());
    
    return [
        'total' => $totalTaches,
        'terminees' => $nombreTerminees,
        'pourcentage' => $pourcentageTerminees,
        'enRetard' => $nombreEnRetard
    ];
}

// Obtenir la classe CSS selon la priorité
function getClassePriorite($priorite) {
    switch($priorite) {
        case 'haute':
            return 'danger';
        case 'moyenne':
            return 'warning';
        case 'basse':
            return 'info';
        default:
            return 'secondary';
    }
}

// Obtenir la classe CSS selon le statut
function getClasseStatut($statut) {
    switch($statut) {
        case 'terminée':
            return 'success';
        case 'en cours':
            return 'primary';
        case 'à faire':
            return 'secondary';
        default:
            return 'secondary';
    }
}
?>
