<?php
require_once("functions.php");

// Traitement des différentes actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    
    switch($action) {
        case 'ajouter':
            $titre = $_POST['titre'] ?? '';
            $description = $_POST['description'] ?? '';
            $priorite = $_POST['priorite'] ?? 'moyenne';
            $statut = $_POST['statut'] ?? 'A Faire';
            $dateLimite = $_POST['dateLimite'] ?? '';
            $responsable = $_POST['responsable'] ?? '';
            
            if (!empty($titre) && !empty($dateLimite) && !empty($responsable)) {
                ajouterTache($titre, $description, $priorite,$statut, $dateLimite, $responsable);
                header('Location: ../Index.php?page=indexTache&message=ajout_success');
            } else {
                header('Location: ../Index.php?page=ajouterTache&error=champs_manquants');
            }
            exit;
            
        case 'modifier':
            $id = $_POST['id'] ?? 0;
            $titre = $_POST['titre'] ?? '';
            $description = $_POST['description'] ?? '';
            $priorite = $_POST['priorite'] ?? 'moyenne';
            $statut = $_POST['statut'] ?? 'à faire';
            $dateLimite = $_POST['dateLimite'] ?? '';
            $responsable = $_POST['responsable'] ?? '';
            
            if ($id && !empty($titre) && !empty($dateLimite) && !empty($responsable)) {
                modifierTache($titre, $description, $priorite, $statut, $dateLimite, $responsable);
                header('Location: ../Index.php?page=indexTache&message=modif_success');
            } else {
                header('Location: ../Index.php?page=modifierTache&id=' . $id . '&error=champs_manquants');
            }
            exit;
    }
}

// Traitement des actions GET
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $action = $_GET['action'] ?? '';
    
    switch($action) {
        case 'supprimer':
            $id = $_GET['id'] ?? 0;
            if ($id) {
                supprimerTache($id);
                header('Location: ../Index.php?page=indexTache&message=suppression_success');
            }
            exit;
            
        case 'changerStatut':
            $id = $_GET['id'] ?? 0;
            $statut = $_GET['statut'] ?? '';
            
            if ($id && !empty($statut)) {
                changerStatut($id, $statut);
                header('Location: ../Index.php?page=indexTache&message=statut_change');
            }
            exit;
    }
}

// Redirection par défaut
header('Location: ../Index.php');
exit;
?>
